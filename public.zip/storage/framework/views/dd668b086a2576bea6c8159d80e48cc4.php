<div>
    <div class="profile-per">
        <div class="row">
            <div class="col-lg-4">
                <img src="<?php echo e($customer->documents?->first() ? asset('storage/' . $customer->documents?->first()->image_url) : asset('frontend/assets/images/default.jpg')); ?>"
                    class="img-fluid img-radi">
            </div>

            <div class="col-lg-8">

                <h4 class="pro-hea">Hi <?php echo e($customer->name); ?></h4>
                <h6 class="profile-des">
                    <?php echo e($customer->customer_id); ?>

                    <a href="<?php echo e(route('admin.customer.edit', $customer->id)); ?>">
                        <span class="co-editprofile">
                            <i class="fas fa-pencil"></i>
                            Edit Profile
                        </span>
                    </a>
                </h6>
            </div>
            <div class="col-12">
                <div class="mt-4">
                    <p class="last-login btn btn-sm btn-outline-secondary w-100">
                        <?php if($customer->last_login_time): ?>
                            Last login:
                            <?php echo e((new DateTime($customer->last_login_time))->setTimezone(new DateTimeZone('Asia/Kolkata'))->format('jS M g:i A')); ?>

                        <?php else: ?>
                            Last login: Not Available
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
        <hr>
        <!-- /////navigation vertical//// -->
        <nav class="nav flex-column">
            
            <a class="nav-link" aria-current="page" href="<?php echo e(route('customer.matches')); ?>"> Profiles <i
                    class="fa fa-chevron-right chev-icon"></i></a>
            <a class="nav-link" href="<?php echo e(route('customer.shortlist')); ?>">Short Listed Matches <i class="fa fa-chevron-right chev-icon4"></i></a>
            <a class="nav-link" href="<?php echo e(route('friend.requests')); ?>">
                Received Requests <i class="fa fa-chevron-right chev-icon4"></i>
            </a>
        </nav>
        <!-- //// -->
    </div>
</div>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/components/profilelayout.blade.php ENDPATH**/ ?>