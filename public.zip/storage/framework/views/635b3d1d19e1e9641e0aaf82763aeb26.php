<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'create' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'create' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="page-header px-0">
    <div class="row">
        <div class="col-lg-4 d-flex align-items-center ">
            <h3><?php echo e($title); ?></h3>
        </div>
        <div class="col-lg-8">
            <div class="row d-flex justify-content-end">
                <?php if($create): ?>
                    <div class="col-lg-2">
                        <a href="<?php echo e($create); ?>" class="add-btn bg-success text-white">Add</a>
                    </div>
                <?php endif; ?>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/components/admin/breadcrumb.blade.php ENDPATH**/ ?>