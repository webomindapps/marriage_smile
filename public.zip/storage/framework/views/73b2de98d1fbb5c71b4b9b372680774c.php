<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('frontend/assets/css/search.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>
    <section class="dash-pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <?php if (isset($component)) { $__componentOriginal12656a09ba8fb461722110a71db80b16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12656a09ba8fb461722110a71db80b16 = $attributes; } ?>
<?php $component = App\View\Components\Profilelayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profilelayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Profilelayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12656a09ba8fb461722110a71db80b16)): ?>
<?php $attributes = $__attributesOriginal12656a09ba8fb461722110a71db80b16; ?>
<?php unset($__attributesOriginal12656a09ba8fb461722110a71db80b16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12656a09ba8fb461722110a71db80b16)): ?>
<?php $component = $__componentOriginal12656a09ba8fb461722110a71db80b16; ?>
<?php unset($__componentOriginal12656a09ba8fb461722110a71db80b16); ?>
<?php endif; ?>
                </div>
                <div class="col-lg-8 new-gp">
                    <div class="bg-white-search p-5">
                        <h4 class="mb-4">Received Requests:-</h4>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border p-3 mb-3 row align-items-center rounded">
                                <div class="picture col-2">
                                    <img src="<?php echo e($request->sender->documents->first() ? asset('storage/' . $request->sender->documents->first()->image_url) : asset('frontend/assets/images/default.jpg')); ?>"
                                        class="img-fluid img-radi" style="width: 60px; height: 60px;" alt="">
                                </div>
                                <div class="content col-7">
                                    <p><?php echo e($request->sender?->name); ?></p>

                                </div>
                                <div class="col-3">
                                    <div class="d-flex">
                                        <a class="btn btn-sm btn-danger"
                                            href="<?php echo e(route('reject.request', $request->id)); ?>">Reject</a>
                                        <a class="btn btn-sm btn-success ms-2"
                                            href="<?php echo e(route('accept.request', $request->id)); ?>">Accept</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/customer/friend-requests.blade.php ENDPATH**/ ?>