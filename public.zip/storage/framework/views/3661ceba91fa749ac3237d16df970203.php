<section class="bg-blue-pic">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-7 mp-0 below-sec">

                <h5 class="h5-find">Find Your Life Partner With
                </h5>
                <h2 class="sec-heading missin-h mb-4 text-white">
                    Marriage Smile
                </h2>
                <p class="p-desc text-white">Your perfect life partner is just a match away! Sign up with Marriage
                    Smile today and make the right choice!
                </p>

                <div class="banner-btn">
                    <a href="" contenteditable="false" style="cursor: pointer;">Register Now</a>
                </div>
            </div>
            <div class="col-lg-5 mp-0">

                <img src="<?php echo e(asset('frontend/assets/images/Marriage-smile.jpg')); ?>" class="img-fluid " alt="">

            </div>

        </div>
    </div>
</section><?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/sections/bg-blue-pic.blade.php ENDPATH**/ ?>