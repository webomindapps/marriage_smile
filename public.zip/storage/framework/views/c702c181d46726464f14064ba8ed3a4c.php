<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="dropdown nav-item <?php echo e(str_contains(url()->current(), $menu['name']) ? 'active' : ''); ?>">
        <a class="nav-link"
            <?php if(!$menu['isSubMenu']): ?> href="<?php echo e(route($menu['route'], $menu['params'] ?? [])); ?>" <?php endif; ?>>
            <span class="shape1"></span>
            <span class="shape2"></span>
            <i class="<?php echo e($menu['icon']); ?>"></i>
            <span class="link_names"><?php echo e($menu['title']); ?></span>
            <?php if($menu['isSubMenu']): ?>
                <span class="right-arr">
                    <i class='bx bx-chevron-down'></i>
                </span>
            <?php endif; ?>
        </a>

        <?php if($menu['isSubMenu']): ?>
            <ul class="dropdown_menu">
                <?php $__currentLoopData = $menu['subMenus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route($subMenu['route'], $subMenu['params'] ?? [])); ?>">
                            <i class='bx bx-chevron-right'></i>
                            <?php echo e($subMenu['title']); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/components/admin/side-bar.blade.php ENDPATH**/ ?>