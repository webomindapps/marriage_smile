<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Doaba')); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous">
    <link defer rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
</head>

<body>
    <div class="sidebar active">
        <div class="logo_content">
            <div class="logo">
                <div href="">
                    <img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" class="admin-logo" alt="">
                </div>
            </div>
            <i class='bx bx-menu-alt-right' id="btn" style="font-size: 25px; cursor: pointer;"></i>
        </div>
        <ul class="nav_list">
            <?php if (isset($component)) { $__componentOriginal8119491cf1a0e0c3dac3525712231a0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8119491cf1a0e0c3dac3525712231a0f = $attributes; } ?>
<?php $component = App\View\Components\Admin\SideBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.side-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\SideBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8119491cf1a0e0c3dac3525712231a0f)): ?>
<?php $attributes = $__attributesOriginal8119491cf1a0e0c3dac3525712231a0f; ?>
<?php unset($__attributesOriginal8119491cf1a0e0c3dac3525712231a0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8119491cf1a0e0c3dac3525712231a0f)): ?>
<?php $component = $__componentOriginal8119491cf1a0e0c3dac3525712231a0f; ?>
<?php unset($__componentOriginal8119491cf1a0e0c3dac3525712231a0f); ?>
<?php endif; ?>
        </ul>

    </div>
    <!-- top bar  -->


    <div class="home_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row top_bar bg-white shadow-sm">
                        <?php echo $__env->make('admin.layout.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="main">
            <div class="row px-2">
                <?php if(session('success')): ?>
                    <div class="col-lg-12 mt-2 session-success" id="session-success">
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php echo e($slot); ?>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" crossorigin="anonymous"
        referrerpolicy="no-referrer"></script>
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/table.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $(".profile-icon").click(function() {
                $(".profile-drop").toggle();
            });
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let btn = document.querySelector("#btn");
            let sidebar = document.querySelector(".sidebar");
            let dropdownLinks = document.querySelectorAll(".dropdown");

            btn.onclick = function() {
                sidebar.classList.toggle("active");
            }

            dropdownLinks.forEach(link => {
                link.addEventListener("click", function(e) {

                    let dropdownMenu = this.querySelector(".dropdown_menu");
                    dropdownMenu.classList.toggle("open");
                });
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/admin/layout/admin.blade.php ENDPATH**/ ?>