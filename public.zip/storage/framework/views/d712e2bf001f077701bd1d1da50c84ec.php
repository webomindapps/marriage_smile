<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('frontend/assets/css/search.css')); ?>" rel="stylesheet">
        <style>
            .profile-edit {
                background: #fff;
                padding: 50px 50px 41px 50px;
                border-radius: 7px;
                border: 1px solid #cccccc59;
            }

            .bi-ftre {
                background: #fff;
                padding: 13px 10px;
                border-radius: 6px;
                border: 1px solid #00000024;
            }

            input::placeholder {
                font-size: 15px !important;
            }

            select.form-select {
                background-color: white;
                margin-top: 0px;
                margin-bottom: 14px;
                border: 1px solid #00000021 !important;
                padding-left: 12px !important;
                font-size: 15px;
                border-radius: 6px !important;
                color: #232323;
                background-size: 15px 34px !important;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <section class="dash-pad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <?php if (isset($component)) { $__componentOriginal12656a09ba8fb461722110a71db80b16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12656a09ba8fb461722110a71db80b16 = $attributes; } ?>
<?php $component = App\View\Components\Profilelayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profilelayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Profilelayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12656a09ba8fb461722110a71db80b16)): ?>
<?php $attributes = $__attributesOriginal12656a09ba8fb461722110a71db80b16; ?>
<?php unset($__attributesOriginal12656a09ba8fb461722110a71db80b16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12656a09ba8fb461722110a71db80b16)): ?>
<?php $component = $__componentOriginal12656a09ba8fb461722110a71db80b16; ?>
<?php unset($__componentOriginal12656a09ba8fb461722110a71db80b16); ?>
<?php endif; ?>
                    <div class="profile-per mt-2">
                        <nav class="nav flex-column">
                            <a class="btn btn-danger" href=""
                                onclick="return confirm('Are you sure you want to delete this customer?');"> Delete
                                Account</a>
                            <a href="" class="btn btn-info mt-2">Hold</a>
                            <a href="<?php echo e(route('customer.logout')); ?>" class="btn btn-secondary mt-2">Logout</a>
                        </nav>
                    </div>
                </div>
                <div class="col-lg-8 new-gp ">
                    <div class="profile-edit">
                        <form class="row g-3" id="registrationForm"
                            action="<?php echo e(route('admin.customer.edit', $customer->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5 class="h5-find pd-1"><i class="fas fa-user-circle"></i> Profile Details
                                <span>(Verified)</span>
                            </h5>
                            <div class="col-6">
                                <select class="form-control" id="nationality" name="nationality">
                                    <option value="" disabled>Select Nationality</option>
                                    <option value="Indian" <?php echo e($customer->nationality == 'Indian' ? 'selected' : ''); ?>>Indian
                                    </option>
                                </select>
                                
                                <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <select class="form-control" id="religion" name="religion">
                                    <option value=""disabled selected>Select Religion</option>
                                    <option value="hindu" <?php echo e($customer->details->religion == 'hindu' ? 'selected' : ''); ?>>
                                        Hindu
                                    </option>
                                </select>
                                <div id="religionerror" class="text-danger ps-0 mb-2 d-none" style="font-size: 13px;">
                                    Please select your Religion.
                                </div>
                                <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <select class="form-control" id="gender" name="gender">
                                    <option value="" disabled
                                        <?php echo e(empty($customer->details->gender) ? 'selected' : ''); ?>>
                                        Select
                                        Gender</option>
                                    <option value="male" <?php echo e($customer->details->gender == 'male' ? 'selected' : ''); ?>>Male
                                    </option>
                                    <option value="female" <?php echo e($customer->details->gender == 'female' ? 'selected' : ''); ?>>
                                        Female
                                    </option>
                                </select>
                                <div id="gendererror" class="text-danger ps-0 mb-2 d-none" style="font-size: 13px;">
                                    Please select Gender
                                </div>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="height" name="height"
                                    value="<?php echo e($customer->details->height ?? ''); ?>" placeholder="Height in ft" required>
                                <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="color" name="colour"
                                    value="<?php echo e($customer->details->colour ?? ''); ?>" placeholder="Colour" required>
                                <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e($customer->name); ?>" placeholder="Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <select class="form-control" id="qualification" name="qualification" required>
                                    <option value="" disabled
                                        <?php echo e(empty($customer->details->qualification) ? 'selected' : ''); ?>>
                                        Select Qualification</option>
                                    <option value="BE"
                                        <?php echo e($customer->details->qualification == 'BE' ? 'selected' : ''); ?>>
                                        BE
                                    </option>
                                    <option value="B Com"
                                        <?php echo e($customer->details->qualification == 'B Com' ? 'selected' : ''); ?>>B Com
                                    </option>
                                    <option value="B Sc"
                                        <?php echo e($customer->details->qualification == 'B Sc' ? 'selected' : ''); ?>>
                                        B Sc
                                    </option>
                                    <option value="B Tech"
                                        <?php echo e($customer->details->qualification == 'B Tech' ? 'selected' : ''); ?>>B Tech
                                    </option>
                                    <option value="BBA"
                                        <?php echo e($customer->details->qualification == 'BBA' ? 'selected' : ''); ?>>
                                        BBA
                                    </option>
                                    <option value="BCA"
                                        <?php echo e($customer->details->qualification == 'BCA' ? 'selected' : ''); ?>>
                                        BCA
                                    </option>
                                    <option value="M Sc"
                                        <?php echo e($customer->details->qualification == 'M Sc' ? 'selected' : ''); ?>>
                                        M Sc
                                    </option>
                                    <option value="M Tech"
                                        <?php echo e($customer->details->qualification == 'M Tech' ? 'selected' : ''); ?>>M Tech
                                    </option>
                                    <option value="MBA"
                                        <?php echo e($customer->details->qualification == 'MBA' ? 'selected' : ''); ?>>
                                        MBA
                                    </option>
                                    <option value="MCA"
                                        <?php echo e($customer->details->qualification == 'MCA' ? 'selected' : ''); ?>>
                                        MCA
                                    </option>
                                    <option value="Diploma"
                                        <?php echo e($customer->details->qualification == 'Diploma' ? 'selected' : ''); ?>>
                                        Diploma</option>
                                    <option value="ITI"
                                        <?php echo e($customer->details->qualification == 'ITI' ? 'selected' : ''); ?>>
                                        ITI
                                    </option>
                                    <option value="Others"
                                        <?php echo e($customer->details->qualification == 'Others' ? 'selected' : ''); ?>>Others
                                    </option>
                                    <option value="10th"
                                        <?php echo e($customer->details->qualification == '10th' ? 'selected' : ''); ?>>
                                        10th
                                    </option>
                                    <option value="12th"
                                        <?php echo e($customer->details->qualification == '12th' ? 'selected' : ''); ?>>
                                        12th
                                    </option>
                                </select>
                                <div id="qualificationerror" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select Qualification
                                </div>
                                <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group" id="other-qualification-field"
                                style="display: <?php echo e($customer->details->qualification == 'Others' ? 'block' : 'none'); ?>;">
                                <label for="other_qualification">Please Specify</label>
                                <input type="text" class="form-control" id="other_qualification"
                                    name="other_qualification"
                                    value="<?php echo e($customer->details->other_qualification ?? ''); ?>"
                                    placeholder="Enter your qualification">
                                <?php $__errorArgs = ['other_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6 position-relative">
                                <input type="text" name="dob" class="form-control"
                                    value="<?php echo e($customer->details->dob ?? ''); ?>" placeholder="DOB"
                                    onfocus="(this.type='date')" onblur="if(this.value===''){this.type='text'}"
                                    id="dob" autocomplete="off" required>
                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" value="<?php echo e($customer->details->age ?? ''); ?>"
                                    placeholder="Age" name="age" id="age" readonly required>
                                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <select class="form-control" id="mother_tongue" name="mother_tongue" required>
                                    <option value="" disabled
                                        <?php echo e($customer->details->mother_tongue ?? old('mother_tongue') ? '' : 'selected'); ?>>
                                        Select Mother Tongue
                                    </option>
                                    <option value="kannada"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'kannada' ? 'selected' : ''); ?>>
                                        Kannada
                                    </option>
                                    <option value="tamil"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'tamil' ? 'selected' : ''); ?>>
                                        Tamil
                                    </option>
                                    <option value="telugu"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'telugu' ? 'selected' : ''); ?>>
                                        Telugu
                                    </option>
                                    <option value="malayalam"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'malayalam' ? 'selected' : ''); ?>>
                                        Malayalam
                                    </option>
                                    <option value="hindi"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'hindi' ? 'selected' : ''); ?>>
                                        Hindi
                                    </option>
                                    <option value="Others"
                                        <?php echo e(($customer->details->mother_tongue ?? old('mother_tongue')) == 'Others' ? 'selected' : ''); ?>>
                                        Others
                                    </option>
                                </select>
                                <div id="mother_tongue_error" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select your Mother Tongue
                                </div>
                                <?php $__errorArgs = ['mother_tongue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group" id="other-mothertongue-field" style="display: none;">
                                <label for="other_mothertongue">Please Specify</label>
                                <input type="text" class="form-control" id="other_mothertongue"
                                    name="other_mothertongue"
                                    value="<?php echo e($customer->details->other_mothertongue ?? old('other_mothertongue')); ?>"
                                    placeholder="Enter your Mother Tongue">
                                <?php $__errorArgs = ['other_mothertongue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="caste" name="caste"
                                    value="<?php echo e($customer->details->caste ?? old('caste')); ?>" placeholder="Caste" required>
                                <?php $__errorArgs = ['caste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" id="gotra" name="gotra"
                                    value="<?php echo e($customer->details->gotra ?? old('gotra')); ?>" placeholder="Gotra" required>
                                <?php $__errorArgs = ['gotra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" id="sun_star" name="sun_star"
                                    value="<?php echo e($customer->details->sun_star ?? old('sun_star')); ?>" placeholder="Sunstar">
                                <?php $__errorArgs = ['sun_star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" id="birth_star" name="birth_star"
                                    value="<?php echo e($customer->details->birth_star ?? old('birth_star')); ?>"
                                    placeholder="Birth Star">
                                <?php $__errorArgs = ['birth_star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <?php
                                    $incomeRanges = [];
                                    for ($start = 1; $start <= 70; $start++) {
                                        $end = $start + 1;
                                        $incomeRanges[] = "{$start}-{$end} Lakh";
                                    }
                                ?>
                                <select class="form-control" id="annual_income" name="annual_income" required>
                                    <option value="" disabled
                                        <?php echo e(!$customer->details->annual_income ? 'selected' : ''); ?>>Select
                                        Annual Income</option>
                                    <?php $__currentLoopData = $incomeRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($range); ?>"
                                            <?php echo e($customer->details->annual_income == $range ? 'selected' : ''); ?>>
                                            <?php echo e($range); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div id="annual_income_error" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select annual Income
                                </div>
                                <?php $__errorArgs = ['annual_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" id="company_name" name="company_name"
                                    value="<?php echo e($customer->details->company_name); ?>" placeholder="Company Name">
                                <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="experience" name="experience"
                                    value="<?php echo e($customer->details->experience); ?>" placeholder="Working Experience"
                                    required>
                                <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <div class="input-group">
                                    <span class="input-group-text" id="country-code">+91</span>
                                    <input type="text" class="form-control" id="phone" name="phone"
                                        minlength="10" maxlength="10" placeholder="Mobile No"
                                        value="<?php echo e($customer->phone ?? old('phone')); ?>"
                                        oninput="this.value = this.value.replace(/\D/g, '')" required>
                                </div>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?php echo e($customer->email); ?>" placeholder="Email id ">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <input type="text" class="form-control" id="aadhar_no" name="aadhar_no"
                                    value="<?php echo e($customer->details->aadhar_no); ?>" placeholder="AADHAR NO" readonly>
                            </div>
                            <div class="col-6">
                                <div id="hobbies-container">
                                    <div class="hobby-row">
                                        <input type="text" class="form-control" name="hobbies" placeholder="Hobbies"
                                            value="<?php echo e($customer->details->hobbies ?? old('hobbies')); ?>" required>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['hobbies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <input type="url" class="form-control" id="facebook_profile" name="facebook_profile"
                                    placeholder="Facebook Profile / Insta Profile"
                                    value="<?php echo e($customer->details->facebook_profile); ?>">
                                <?php $__errorArgs = ['facebook_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <div class="bi-ftre">
                                    <label>Horoscope</label><br />
                                    <input type="file" id="image_path" name="image_path" 
                                        <?php if($customer->documents->isNotEmpty() && $customer->documents->first()->image_path): ?> value="<?php echo e(asset('storage/' . $customer->documents->first()->image_path)); ?>" <?php endif; ?>>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="bi-ftre">
                                    <label>Upload Photo (Maximum 3 photos required)</label><br />
                                    <input type="file" class="image-file" name="image_url[]" id="image_url" multiple
                                        accept="image/*">
                                    <div id="image-preview-container" class="d-flex mt-3">
                                        
                                        <?php if($customer->documents->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $customer->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($document->image_url)): ?>
                                                    <img src="<?php echo e(asset('storage/' . $document->image_url)); ?>"
                                                        class="img-thumbnail" width="100" height="100"
                                                        alt="Uploaded image">
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <select id="marritialstatus" name="marritialstatus" class="form-select" required>
                                    <option value="" disabled
                                        <?php echo e(old('marritialstatus', $customer->details->marritialstatus ?? '') ? '' : 'selected'); ?>>
                                        Marital Status
                                    </option>
                                    <option value="unmarried"
                                        <?php echo e(old('marritialstatus', $customer->details->marritialstatus ?? '') == 'unmarried' ? 'selected' : ''); ?>>
                                        Unmarried
                                    </option>
                                    <option value="divorsed"
                                        <?php echo e(old('marritialstatus', $customer->details->marritialstatus ?? '') == 'divorsed' ? 'selected' : ''); ?>>
                                        Divorced
                                    </option>
                                </select>
                                <?php $__errorArgs = ['marritialstatus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div id="marritialstatuserror" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select Marital Status
                                </div>
                            </div>

                            <div class="col-md-12 mt-3" id="children-container" style="display: none;">
                                <input type="number" id="numberOfChildren" name="no_of_children" class="form-control"
                                    placeholder="Enter number of children"
                                    value="<?php echo e(old('no_of_children', $customer->details->no_of_children ?? '')); ?>"
                                    min="1">
                            </div>
                            <div class="col-md-12 mt-3" id="children-details-container" style="display: none;">
                            </div>
                            <div class="col-md-12">
                                <select id="relationship_manager" name="req_rel_manager" class="form-select" required>
                                    <option value="" disabled
                                        <?php echo e($customer->details->req_rel_manager ? '' : 'selected'); ?>>
                                        Do you need a relationship manager to search on behalf of you?
                                    </option>
                                    <option value="Yes"
                                        <?php echo e($customer->details->req_rel_manager == 'Yes' ? 'selected' : ''); ?>>Yes
                                    </option>
                                    <option value="No"
                                        <?php echo e($customer->details->req_rel_manager == 'No' ? 'selected' : ''); ?>>No
                                    </option>
                                </select>
                                <?php $__errorArgs = ['req_rel_manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <textarea class="form-control" id="inputname" name="expectations" placeholder="Expectations?"><?php echo e($customer->details->expectations); ?></textarea>
                                <?php $__errorArgs = ['expectations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <h5 class="h5-find pd-2"><i class="fas fa-users"></i> My Family Details </h5>

                            <div class="col-6">
                                <input type="text" class="form-control" id="father_name" name="father_name"
                                    placeholder="Father Name" value="<?php echo e($customer->details->father_name); ?>">
                                <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="father_occupation"
                                    name="father_occupation" placeholder="Father Occupation"
                                    value="<?php echo e($customer->details->father_occupation); ?>">
                                <?php $__errorArgs = ['father_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="mother_name" name="mother_name"
                                    placeholder="Mother Name" value="<?php echo e($customer->details->mother_name); ?>">
                                <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" id="mother_occupation"
                                    name="mother_occupation" placeholder="Mother Occupation"
                                    value="<?php echo e($customer->details->mother_occupation); ?>">
                                <?php $__errorArgs = ['mother_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control" id="siblings" name="siblings"
                                    placeholder="Number of Siblings" value="<?php echo e($customer->details->siblings); ?>" required>
                                <?php $__errorArgs = ['siblings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div id="siblings-details-container" class="row mt-3">
                                
                            </div>

                            <div class="col-12">
                                <input type="text" class="form-control" id="locations" name="locations"
                                    placeholder="Present Address"
                                    value="<?php echo e($customer->details->locations ?? old('locations')); ?>" required>
                                <?php $__errorArgs = ['locations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12" id="present-house-status-container"
                                style="<?php echo e(isset($customer->details->present_house_status) ? '' : 'display: none;'); ?>">
                                <select id="present_house_status" name="present_house_status" class="form-select"
                                    required>
                                    <option value="" disabled <?php echo e(old('present_house_status') ? '' : 'selected'); ?>>
                                        Select House Status
                                    </option>
                                    <option value="own"
                                        <?php echo e(($customer->details->present_house_status ?? old('present_house_status')) == 'own' ? 'selected' : ''); ?>>
                                        Own
                                        House</option>
                                    <option value="rent"
                                        <?php echo e(($customer->details->present_house_status ?? old('present_house_status')) == 'rent' ? 'selected' : ''); ?>>
                                        Rent
                                        House</option>
                                </select>
                                <?php $__errorArgs = ['present_house_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <input type="text" class="form-control" id="permanent_locations"
                                    name="permanent_locations" placeholder="Permanent Address"
                                    value="<?php echo e($customer->details->permanent_locations ?? old('permanent_locations')); ?>"
                                    required>
                                <?php $__errorArgs = ['permanent_locations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12" id="permanent-house-status-container"
                                style="<?php echo e(isset($customer->details->permanent_house_status) ? '' : 'display: none;'); ?>">
                                <label for="permanent_house_status">House Status for Permanent Address</label>
                                <select id="permanent_house_status" name="permanent_house_status" class="form-select"
                                    required>
                                    <option value="" disabled
                                        <?php echo e(old('permanent_house_status') ? '' : 'selected'); ?>>
                                        Select House Status
                                    </option>
                                    <option value="own"
                                        <?php echo e(($customer->details->permanent_house_status ?? old('permanent_house_status')) == 'own' ? 'selected' : ''); ?>>
                                        Own
                                        House</option>
                                    <option value="rent"
                                        <?php echo e(($customer->details->permanent_house_status ?? old('permanent_house_status')) == 'rent' ? 'selected' : ''); ?>>
                                        Rent
                                        House</option>
                                </select>
                                <?php $__errorArgs = ['permanent_house_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12">
                                <select id="asset_value" name="asset_value" class="form-select" required>
                                    <option value="" disabled
                                        <?php echo e(isset($customer->details->asset_value) ? '' : 'selected'); ?>>
                                        Asset Value</option>
                                    <option value="5lakh - 10lakh"
                                        <?php echo e(isset($customer->details->asset_value) && $customer->details->asset_value == '5lakh - 10lakh' ? 'selected' : ''); ?>>
                                        5lakh - 10lakh</option>
                                    <option value="10lakh - 20lakh"
                                        <?php echo e(isset($customer->details->asset_value) && $customer->details->asset_value == '10lakh - 20lakh' ? 'selected' : ''); ?>>
                                        10lakh - 20lakh</option>
                                    <option value="Will Disclose Later"
                                        <?php echo e(isset($customer->details->asset_value) && $customer->details->asset_value == 'Will Disclose Later' ? 'selected' : ''); ?>>
                                        Will Disclose Later</option>
                                </select>
                                <?php $__errorArgs = ['asset_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div id="asset_value_error" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select the Asset Value
                                </div>
                            </div>

                            <h5 class="h5-find pd-2"><i class="fas fa-comment-dots"></i> How I Want to Talk to My Matches
                            </h5>
                            <div class="col-md-12">
                                <select id="preferreday" name="preferreday" class="form-select" required>
                                    <option value="" disabled
                                        <?php echo e(isset($customer->details->preferreday) ? '' : 'selected'); ?>>
                                        Preferred Day to Talk</option>
                                    <option value="Any Day"
                                        <?php echo e(isset($customer->details->preferreday) && $customer->details->preferreday == 'Any Day' ? 'selected' : ''); ?>>
                                        Any Day</option>
                                    <option value="selectday"
                                        <?php echo e(isset($customer->details->preferreday) && $customer->details->preferreday == 'selectday' ? 'selected' : ''); ?>>
                                        Select the day</option>
                                </select>
                                <?php $__errorArgs = ['preferreday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 <?php echo e(isset($customer->details->preferreday) && $customer->details->preferreday == 'selectday' ? '' : 'hidden'); ?>"
                                id="timings-container">
                                <label for="timings">Timings</label>
                                <input type="datetime-local" name="timings" class="form-control"
                                    value="<?php echo e($customer->details->timings ?? old('timings')); ?>" id="timings">
                            </div>

                            <div class="col-12">
                                <input type="text" class="form-control" id="preferred_contact_no"
                                    name="preferred_contact_no" minlength="10" maxlength="10"
                                    placeholder="Preferred contact number to talk"
                                    oninput="this.value = this.value.replace(/\D/g, '')"
                                    value="<?php echo e($customer->details->preferred_contact_no ?? old('preferred_contact_no')); ?>"
                                    required>
                                <?php $__errorArgs = ['preferred_contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <select class="form-control" id="contact_related_to" name="contact_related_to" required>
                                    <option value="" disabled
                                        <?php echo e(isset($customer->details->contact_related_to) ? '' : 'selected'); ?>>Relation
                                    </option>
                                    <option value="father"
                                        <?php echo e(isset($customer->details->contact_related_to) && $customer->details->contact_related_to == 'father' ? 'selected' : ''); ?>>
                                        Father</option>
                                    <option value="mother"
                                        <?php echo e(isset($customer->details->contact_related_to) && $customer->details->contact_related_to == 'mother' ? 'selected' : ''); ?>>
                                        Mother</option>
                                    <option value="brother"
                                        <?php echo e(isset($customer->details->contact_related_to) && $customer->details->contact_related_to == 'brother' ? 'selected' : ''); ?>>
                                        Brother</option>
                                    <option value="sister"
                                        <?php echo e(isset($customer->details->contact_related_to) && $customer->contact_related_to == 'sister' ? 'selected' : ''); ?>>
                                        Sister</option>
                                </select>
                                <div id="contact_related_to_error" class="text-danger ps-0 mb-2 d-none"
                                    style="font-size: 13px;">
                                    Please select Qualification
                                </div>
                                <?php $__errorArgs = ['contact_related_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-0 mb-2" style="font-size: 13px;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn bt-register">Update Profile</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        const inputState = document.getElementById("preferreday");
        const timingsContainer = document.getElementById("timings-container");
        const timingsInput = document.getElementById("timings");

        inputState.addEventListener("change", function() {
            if (inputState.value === "selectday") {
                timingsContainer.classList.remove("hidden");
                timingsInput.focus();
            } else {
                timingsContainer.classList.add("hidden");
                timingsInput.value = "";
            }
        });
    </script>
    <script>
        document.getElementById('qualification').addEventListener('change', function() {
            const otherQualificationField = document.getElementById('other-qualification-field');
            otherQualificationField.style.display = this.value === 'Others' ? 'block' : 'none';
        });
    </script>
    <script>
        document.getElementById('dob').addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();
            let age = today.getFullYear() - dob.getFullYear();
            const monthDiff = today.getMonth() - dob.getMonth();

            // Adjust age if the current date is before the birth date in the current year
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
                age--;
            }

            document.getElementById('age').value = age > 0 ? age : '';
        });
    </script>
    <script>
        document.getElementById('mother_tongue').addEventListener('change', function() {
            const otherMotherTongueField = document.getElementById('other-mothertongue-field');
            if (this.value === 'Others') {
                otherMotherTongueField.style.display = 'block';
            } else {
                otherMotherTongueField.style.display = 'none';
            }
        });

        window.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('mother_tongue').value === 'Others') {
                document.getElementById('other-mothertongue-field').style.display = 'block';
            }
        });
    </script>
    <script>
        document.getElementById("image_url").addEventListener("change", function(event) {
            const previewContainer = document.getElementById("image-preview-container");
            previewContainer.innerHTML = "";
            const files = event.target.files;

            Array.from(files).forEach((file, index) => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imageWrapper = document.createElement("div");
                    imageWrapper.style.marginRight = "10px";
                    imageWrapper.style.textAlign = "center";
                    const img = document.createElement("img");
                    img.src = e.target.result;
                    img.alt = `Picture ${index + 1}`;
                    img.style.width = "100px";
                    img.style.height = "100px";
                    img.style.objectFit = "cover";
                    img.style.border = "1px solid #ccc";
                    img.style.borderRadius = "4px";

                    const label = document.createElement("p");
                    label.textContent = `Picture ${index + 1}`;
                    label.style.marginTop = "5px";
                    label.style.fontSize = "14px";

                    imageWrapper.appendChild(img);
                    imageWrapper.appendChild(label);

                    previewContainer.appendChild(imageWrapper);
                };

                reader.readAsDataURL(file);
            });
        });
    </script>
    <script>
        document.getElementById("marritialstatus").addEventListener("change", function() {
            const status = this.value;
            const childrenContainer = document.getElementById("children-container");
            const childrenDetailsContainer = document.getElementById("children-details-container");

            if (status === "divorsed") {
                childrenContainer.style.display = "block";
            } else {
                childrenContainer.style.display = "none";
                childrenDetailsContainer.style.display = "none";
                childrenDetailsContainer.innerHTML = "";
            }
        });

        document.getElementById("numberOfChildren").addEventListener("input", function() {
            const count = parseInt(this.value);
            const childrenDetailsContainer = document.getElementById("children-details-container");

            childrenDetailsContainer.innerHTML = "";

            if (!isNaN(count) && count > 0) {
                childrenDetailsContainer.style.display = "block";

                for (let i = 1; i <= count; i++) {
                    const childRow = document.createElement("div");
                    childRow.classList.add("row", "mb-3", "align-items-center");

                    const genderContainer = document.createElement("div");
                    genderContainer.classList.add("col-6");
                    const genderLabel = document.createElement("label");
                    genderLabel.textContent = `Child ${i} Gender`;
                    const genderSelect = document.createElement("select");
                    genderSelect.classList.add("form-select");
                    genderSelect.name = `child_${i}_gender`;
                    genderSelect.innerHTML = `
                        <option value="" disabled selected>Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    `;
                    genderContainer.appendChild(genderLabel);
                    genderContainer.appendChild(genderSelect);

                    const ageContainer = document.createElement("div");
                    ageContainer.classList.add("col-6");
                    const ageLabel = document.createElement("label");
                    ageLabel.textContent = `Child ${i} Age`;
                    const ageInput = document.createElement("input");
                    ageInput.type = "number";
                    ageInput.name = `child_${i}_age`;
                    ageInput.classList.add("form-control");
                    ageInput.placeholder = `Enter Child ${i} Age`;
                    ageInput.min = 0;
                    ageContainer.appendChild(ageLabel);
                    ageContainer.appendChild(ageInput);

                    childRow.appendChild(genderContainer);
                    childRow.appendChild(ageContainer);

                    childrenDetailsContainer.appendChild(childRow);
                }
            } else {
                childrenDetailsContainer.style.display = "none";
            }
        });
    </script>
    <script>
        document.getElementById("siblings").addEventListener("input", function() {
            const count = parseInt(this.value);
            const siblingsDetailsContainer = document.getElementById("siblings-details-container");

            siblingsDetailsContainer.innerHTML = "";

            if (!isNaN(count) && count > 0) {
                for (let i = 1; i <= count; i++) {
                    const siblingRow = document.createElement("div");
                    siblingRow.classList.add("row", "mb-3", "align-items-center");

                    const maritalStatusContainer = document.createElement("div");
                    maritalStatusContainer.classList.add("col-6");
                    const maritalStatusLabel = document.createElement("label");
                    maritalStatusLabel.textContent = `Sibling ${i} Marital Status`;
                    const maritalStatusSelect = document.createElement("select");
                    maritalStatusSelect.classList.add("form-select");
                    maritalStatusSelect.name = `sibling_${i}_marital_status`;
                    maritalStatusSelect.innerHTML = `
                        <option value="" disabled selected>Select Status</option>
                        <option value="married">Married</option>
                        <option value="unmarried">Unmarried</option>
                    `;
                    maritalStatusContainer.appendChild(maritalStatusLabel);
                    maritalStatusContainer.appendChild(maritalStatusSelect);

                    const ageRelationContainer = document.createElement("div");
                    ageRelationContainer.classList.add("col-6");
                    const ageRelationLabel = document.createElement("label");
                    ageRelationLabel.textContent = `Sibling ${i} Age Relation`;
                    const ageRelationSelect = document.createElement("select");
                    ageRelationSelect.classList.add("form-select");
                    ageRelationSelect.name = `sibling_${i}_age_relation`;
                    ageRelationSelect.innerHTML = `
                        <option value="" disabled selected>Select Relation</option>
                        <option value="younger">Younger</option>
                        <option value="older">Older</option>
                    `;
                    ageRelationContainer.appendChild(ageRelationLabel);
                    ageRelationContainer.appendChild(ageRelationSelect);

                    siblingRow.appendChild(maritalStatusContainer);
                    siblingRow.appendChild(ageRelationContainer);
                    siblingsDetailsContainer.appendChild(siblingRow);
                }
            }
        });
    </script>
    <script>
        document.getElementById("locations").addEventListener("input", function() {
            const presentAddress = this.value.trim();
            const presentStatusContainer = document.getElementById("present-house-status-container");

            if (presentAddress) {
                presentStatusContainer.style.display = "block";
            } else {
                presentStatusContainer.style.display = "none";
            }
        });

        document.getElementById("permanent_locations").addEventListener("input", function() {
            const permanentAddress = this.value.trim();
            const permanentStatusContainer = document.getElementById("permanent-house-status-container");

            if (permanentAddress) {
                permanentStatusContainer.style.display = "block";
            } else {
                permanentStatusContainer.style.display = "none";
            }
        });

        // Automatically show containers if values are already populated
        window.addEventListener("DOMContentLoaded", function() {
            const presentAddress = document.getElementById("locations").value.trim();
            const permanentAddress = document.getElementById("permanent_locations").value.trim();

            if (presentAddress) {
                document.getElementById("present-house-status-container").style.display = "block";
            }

            if (permanentAddress) {
                document.getElementById("permanent-house-status-container").style.display = "block";
            }
        });
        document.getElementById("asset_value").addEventListener("change", function() {
            const assetValueError = document.getElementById("asset_value_error");

            if (this.value) {
                assetValueError.classList.add("d-none");
            } else {
                assetValueError.classList.remove("d-none");
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/customer/update.blade.php ENDPATH**/ ?>