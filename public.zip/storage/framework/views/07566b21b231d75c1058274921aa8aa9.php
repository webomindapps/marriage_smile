<section class="bg-pinkish">
    <div class="container">
        <h5 class="h5-find">Finding your perfect</h5>
        <h2 class="sec-heading  mb-4">
            Success Stories
        </h2>
        <div class="row big-y">
            <div class="col-lg-10">
                <div class="owl-carousel owl-theme">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="row box-j">

                                <div class="col-lg-5">
                                    <img src="<?php echo e(asset('storage/' . $item->image_url)); ?>"alt="<?php echo e($item->name); ?>"
                                        class="img-fluid wid-testimoni">
                                </div>
                                <div class="col-lg-7">
                                    <div class="test-main">
                                        <p class="testi-suc-p">
                                            <?php echo e($item->comments); ?>

                                        </p>
                                        <h6 class="testi-succes-h"><?php echo e($item->name); ?></h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/sections/bg-pinkish.blade.php ENDPATH**/ ?>