<section class="faqd">
    <div class="container">
        <h2 class="sec-heading  mb-4">
            Frequently Asked Questions / FAQ
        </h2>
        <div class="accordion">

            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <button id="accordion-button-5" aria-expanded="false">
                        <span class="accordion-title"><?php echo e($item->question); ?>

                        </span>
                        <span class="icon" aria-hidden="true"></span>
                    </button>
                    <div class="accordion-content">
                        <p>
                            <?php echo e($item->answer); ?>


                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/sections/faqd.blade.php ENDPATH**/ ?>