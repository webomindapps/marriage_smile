<section class="bg-blue-pic">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 mp-0">

                <img src="<?php echo e(asset('frontend/assets/images/mission.jpg')); ?>" class="img-fluid im-misson" alt="">

            </div>
            <div class="col-lg-7 mp-0 n-proper">

                <h5 class="h5-find">Marriage smile </h5>
                <h2 class="sec-heading missin-h mb-4 text-white">
                    Mission
                </h2>
                <p class="p-desc text-white">At Marriage Smile, we strongly believe that there is someone for everyone,
                    and we help connect people with their soulmates. In a world filled with people, finding the right
                    person to marry can be difficult, but not anymore! Our mission at Marriage Smile is to bring
                    like-minded people together to help them find their perfect life partner. We make finding soulmates
                    easier by matching your preferences with suitable profiles.
                </p>

                <div class="banner-btn">
                    <a href="" contenteditable="false" style="cursor: pointer;">Know More</a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/sections/bg-blue.blade.php ENDPATH**/ ?>