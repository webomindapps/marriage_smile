<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('frontend/assets/css/login.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>
    <section class="register-f">
        <div class="container">
            <div class="row">
                <div class="col-lg-6"></div>

                <div class="col-lg-6 d-flex align-items-center justify-content-center right-side">
                    <div class="form-2-wrapper">
                        <div class="logo text-center">
                        </div>
                        <h2 class="text-center mb-4 sign-account">Sign Into Your Account</h2>
                        <form action="<?php echo e(route('customer.login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if(session('danger')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <?php echo e(session('danger')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            <?php if(session('verify')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('verify')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            <div class="mb-3 form-box">
                                <input type="text" class="form-control" id="email" name="email"
                                    placeholder="Enter Your Email/Customer id" required="">
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="password" name="password"
                                    placeholder="Enter Your Password" required="">
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="rememberMe">
                                    <label class="form-check-label" for="rememberMe">Remember me</label>
                                    <a href="<?php echo e(route('customer.forgot-password')); ?>" class="text-decoration-none float-end"
                                        contenteditable="false" style="cursor: pointer;">Forget Password</a>
                                </div>

                            </div>
                            <button type="submit" class="btn btn-outline-secondary login-btn w-100 mb-3">Login</button>
                            <div class="social-login mb-3 type--A">
                                <h5 class="text-center mb-3">Social Login</h5>
                                <a href="<?php echo e(route('google.redirect')); ?>"
                                    class="btn btn-outline-secondary mb-3 d-flex align-items-center">
                                    <i class='bx bxl-google me-1'></i> Sign in with <b class="ms-1">Google</b>
                                </a>

                                
                            </div>
                        </form>

                        <!-- Register Link -->
                        <p class="text-center register-test mt-3">Don't have an account ? <a
                                href="<?php echo e(route('customer.register')); ?>" class="text-decoration-none" contenteditable="false"
                                style="cursor: pointer;"> Register
                                here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>