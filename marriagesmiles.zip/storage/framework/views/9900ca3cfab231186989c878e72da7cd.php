<section class="pad-why-choose">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <h5 class="h5-find">Finding your perfect</h5>
                <h2 class="sec-heading  ">
                    Why Choose Marriage Smile?

                </h2>
                <p class="fon-kl">With 100% verified profiles, we strive to protect your data, so you can find your
                    life partner without any worries.
                </p>
                <div class="banner-btn">
                    <a href="" contenteditable="false" style="cursor: pointer;">Know More</a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="row">
                    <div class="col-md-4">
                        <div class="ic1-box line">
                            <img src="<?php echo e(asset('frontend/assets/images/Vector.png')); ?>" class="img-fluid">
                            <div class=" grad-p"><span class="counting" data-count="100">0</span>%</div>
                            <!-- <h5 class="grad-p">100%</h5> -->
                            <p class="why-chose-p">Verified Profiles</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="ic1-box line">
                            <img src="<?php echo e(asset('frontend/assets/images/ring 1.png')); ?>" class="img-fluid">
                            <div class=" grad-p"><span class="counting" data-count="100">0</span>%</div>
                            <p class="why-chose-p">Best Matches</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="ic1-box">
                            <img src="<?php echo e(asset('frontend/assets/images/insurance1.png')); ?>" class="img-fluid">
                            <div class=" grad-p"><span class="counting" data-count="100">0</span>%</div>
                            <p class="why-chose-p">Privacy</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
</section>
<?php /**PATH C:\xampp12\htdocs\marriage_smile\resources\views/frontend/sections/why-choose.blade.php ENDPATH**/ ?>