<section class="form-pad">
    <div class="container">
        <div class="row">
            <div class="box-wid">
                <h5 class="looking-p">I am Looking for a</h5>
                <div class="float_form">
                    <form action="" method="post">

                        <div class="row">
                            <div class="col-lg-2 col-6 pr-0">
                                <select class="form-select form-right" aria-label="Default select example">
                                    <option selected>Gender</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>

                            </div>
                            <div class="col-lg-2 col-6 pr-lg-0 pr-0">
                                <select class="form-select form-right-noage" aria-label="Default select example">
                                    <option selected>Age</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-lg-2 pr-lg-0 pr-0">
                                <select class="form-select form-right" aria-label="Default select example">
                                    <option selected>Age</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>

                            <div class="col-lg-2 pr-lg-0 pr-0">
                                <select class="form-select form-right" aria-label="Default select example">
                                    <option selected>Religion</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-lg-2 pr-lg-0 pr-0">
                                <select class="form-select form-right-nobord" aria-label="Default select example">
                                    <option selected>Mother tongue</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-lg-2 my-auto">
                                <input type="submit" value="Let’s Begin" name="hjgvcxdesty" class="book__now">

                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>