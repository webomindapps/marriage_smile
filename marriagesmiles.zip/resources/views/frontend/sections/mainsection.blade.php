<section id="mainBanner"
    style="background-image: url('/frontend/assets/images/HERO-BANNER.jpg');background-position: center;
background-size: cover;background-repeat: no-repeat;">
    <!-- <div class="carousel-inner">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
            </div>
            <div class="carousel-item  active" data-bs-interval="5000">
                <img src="./images/banner_1 copy.webp" class="d-block w-100" alt="...">
                <div class="carousel-caption">
                    <h5>Advance Your Tech Horizons <br> with Our Proven Experts</h5>
                    <hr class="bg-light border-4 border-top border-light">
                    <p>
                        Push the boundaries of what’s possible with our seasoned technology <br> maestros, guiding you swiftly towards your goals.
                    </p>
                    <div class="banner-btn">
                        <a href="">Explore Our Services</a>
                    </div>
                </div>
            </div>
            <div class="carousel-item" data-bs-interval="5000">
                <img src="./images/banner_2 copy.webp" class="d-block w-100" alt="...">
                <div class="carousel-caption">
                    <h5>THE LEADING OPEN SOURCE <br> PORTAL FOR THE ENTERPRISE</h5>
                    <hr class="bg-light border-4 border-top border-light">
                    <p>Our platform provides essential tools and resources, fostering collaboration, <br>
                        customization, and innovation for businesses worldwide.
                    </p>
                    <div class="banner-btn">
                        <a href="">Explore Our Services</a>
                    </div>
                </div>
            </div>

        </div> -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="carousel-inner">
                    <!-- <div class="carousel-indicators">
                            <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="0" class="active"
                                aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#mainBanner" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                        </div> -->
                    <div class="carousel-item  active" data-bs-interval="5000">
                        <!--   <img src="./images/banner_1 copy.webp" class="d-block w-100" alt="..."> -->
                        <div class="carousel-caption">
                            <h5>Find Your Perfect <br><span class="secondary-co"> Life Partner!</span> </h5>

                            <p>
                                Set the filters, connect with your matches, and<br> find your perfect life partner in
                                just a few clicks!

                            </p>
                            <div class="banner-btn">
                                <a href="">Register free</a>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="carousel-item" data-bs-interval="5000">
                           
                            <div class="carousel-caption">
                                <h5>THE LEADING OPEN SOURCE <br> PORTAL FOR THE ENTERPRISE</h5>
                                <hr class="bg-light border-4 border-top border-light">
                                <p>Our platform provides essential tools and resources, fostering collaboration, <br>
                                    customization, and innovation for businesses worldwide.
                                </p>
                                <div class="banner-btn">
                                    <a href="">Explore Our Services</a>
                                </div>
                            </div>
                        </div> -->

                </div>
            </div>
        </div>
    </div>

</section>
