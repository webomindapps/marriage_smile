<div class="{{ $attributes->get('size') }}">
    <p class="form-title">{{$title}}</p>
</div>